﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTimeTableHelper
{
    public class Course
    {
        public string CourseName { get; set; }
        public bool IsLab { get; set; }
        public int CreditHour { get; set; }
        public bool IsLocked { get; set; }

        public Course(string CourseName, bool IsLab, int CreditHour, bool IsLocked)
        {
            this.CourseName = CourseName;
            this.IsLab = IsLab;
            this.CreditHour = CreditHour;
            this.IsLocked = IsLocked;
        }

        public Course()
        {
            this.CourseName = "";
            this.IsLab = false;
            this.CreditHour = 0;
            this.IsLocked = false;
        }
    }
}
