﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ClassTimeTableHelper
{
    /// <summary>
    /// Interaction logic for AddGridWindow.xaml
    /// </summary>
    public partial class AddGridWindow : Window
    {
        public bool AddGridButtonClicked = false;
        public int NoOfColumns1;
        public int NoOfRows1;
        public ArrayList SelectedDays = new ArrayList();

        public AddGridWindow()
        {
            InitializeComponent();
        }

        // Function to Add Minutes in the Hour
        private double AddMinute(double hour, double minute)
        {
            if (minute >= 1 && minute <= 15)
            {
                hour = hour + 0.25;
            }
            else if (minute >= 16 && minute <= 30)
            {
                hour = hour + 0.50;
            }
            else if (minute >= 31 && minute <= 45)
            {
                hour = hour + 0.75;
            }
            if (minute >= 46 && minute <= 60)
            {
                hour = hour + 1;
            }
            return hour;
        }

        private void clear()
        {
            StartMinuteTextbox.Text = "";
            EndMinuteTextbox.Text = "";
            EachMinuteTextbox.Text = "";
            StartHourTextbox.Text = "";
            EndHourTextbox.Text = "";
            EachHourTextbox.Text = "";
        }

        private void clearall()
        {
            NoOfRows1 = 0;
            clear();
            MonCheckbox.IsChecked = false;
            TueCheckbox.IsChecked = false;
            WedCheckbox.IsChecked = false;
            ThuCheckbox.IsChecked = false;
            FriCheckbox.IsChecked = false;
            SatCheckbox.IsChecked = false;
            SunCheckbox.IsChecked = false;
            AllDayCheckbox.IsChecked = false;
            NoOfColumns1 = 0;
        }

        private void AddGridButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Hour Textboxes cannot be empty
                if (((StartHourTextbox.Text == "") || (Int16.Parse(StartHourTextbox.Text) < 0) || (Int16.Parse(StartHourTextbox.Text) > 24)) ||
                    ((EndHourTextbox.Text == "") || (Int16.Parse(EndHourTextbox.Text) < 0) || (Int16.Parse(EndHourTextbox.Text) > 24)) ||
                    ((EachHourTextbox.Text == "") || (Int16.Parse(EachHourTextbox.Text) < 0) || (Int16.Parse(EachHourTextbox.Text) > 24)))
                {
                    MessageBox.Show("Hours must be greater than or equal to '0' and less than or equal to '23' or cannot be empty.");
                    clear();
                }
                // Minute Textboxes cannot be empty
                else if (((StartMinuteTextbox.Text == "") || (Int16.Parse(StartMinuteTextbox.Text) < 0) || (Int16.Parse(StartMinuteTextbox.Text) > 60)) ||
                     ((EndMinuteTextbox.Text == "") || (Int16.Parse(EndMinuteTextbox.Text) < 0) || (Int16.Parse(EndMinuteTextbox.Text) > 60)) ||
                     ((EachMinuteTextbox.Text == "") || (Int16.Parse(EachMinuteTextbox.Text) < 0) || (Int16.Parse(EachMinuteTextbox.Text) > 60)))
                {
                    MessageBox.Show("Minutes must be greater than or equal to '0' and less than or equal to '59' or cannot be empty.");
                    clear();
                }
                // Creating Grid
                else
                {
                    if (Int32.Parse(StartHourTextbox.Text) < Int32.Parse(EndHourTextbox.Text))
                    {
                        if (Int32.Parse(EachHourTextbox.Text) < (Int32.Parse(EndHourTextbox.Text) - Int32.Parse(StartHourTextbox.Text)))
                        {
                            // Calculating start time to print the first column
                            int StartTimeHour = Int32.Parse(StartHourTextbox.Text);
                            int StartTimeMinute = Int32.Parse(StartMinuteTextbox.Text);

                            //  Calculating StartTime for each class including minutes
                            double start = Double.Parse(StartHourTextbox.Text);
                            double min1 = Double.Parse(StartMinuteTextbox.Text);
                            start = AddMinute(start, min1);

                            //  Calculating EndTime for each class including minutes
                            double end = Double.Parse(EndHourTextbox.Text);
                            double min2 = Double.Parse(EndMinuteTextbox.Text);
                            end = AddMinute(end, min2);

                            // Calculating total no. of hours in which classes are conducted
                            double NoOfHours = 0;
                            for (double i = start + 1; i <= end; i++)
                            {
                                NoOfHours += 1;
                            }

                            //  Calculating duration for each class including minutes
                            double eachClass = Double.Parse(EachHourTextbox.Text);
                            double min3 = Double.Parse(EachMinuteTextbox.Text);
                            eachClass = AddMinute(eachClass, min3);

                            NoOfRows1 = (int)(NoOfHours / eachClass);       // Calculating total No. of rows    

                            foreach (Window window in Application.Current.Windows)
                            {
                                if (window.GetType() == typeof(MainWindow))
                                {
                                    (window as MainWindow).NoOfRows = NoOfRows1;
                                    (window as MainWindow).NoOfColumns = NoOfColumns1;
                                    foreach (int item in SelectedDays)
                                    {
                                        (window as MainWindow).SelectedDays.Add(item);
                                    }
                                    (window as MainWindow).StartTimeHour = Int32.Parse(StartHourTextbox.Text);
                                    (window as MainWindow).StartTimeMinute = Int32.Parse(StartMinuteTextbox.Text);
                                    (window as MainWindow).EachHour = Int32.Parse(EachHourTextbox.Text);
                                    (window as MainWindow).EachMinute = Int32.Parse(EachMinuteTextbox.Text);
                                }
                            }
                            // All variables will be reset to default values for creating the new grid for the next time
                            clearall();
                            AddGridButtonClicked = true;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Please enter suitable time in EachHourTextbox and EachMinuteTextbox");
                            EachHourTextbox.Text = "";
                            EachMinuteTextbox.Text = "";
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("ClassEndHour and ClassEndMinute must be Greater than ClassStartHour and ClassStartMinute");
                        EndHourTextbox.Text = "";
                        EndMinuteTextbox.Text = "";
                    }
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter time in correct format. Only integers will be allowed.");
                clearall();
            }


        }

        // Function for 'AllDay' CheckBox
        private void AllDayCheckbox_Checked(object sender, RoutedEventArgs e)
        {
            MonCheckbox.IsChecked = true;
            TueCheckbox.IsChecked = true;
            WedCheckbox.IsChecked = true;
            ThuCheckbox.IsChecked = true;
            FriCheckbox.IsChecked = true;
            SatCheckbox.IsChecked = true;
            SunCheckbox.IsChecked = true;
            NoOfColumns1 = 7;
        }

        // Function for 'AllDay' CheckBox
        private void AllDayCheckbox_Unchecked(object sender, RoutedEventArgs e)
        {
            MonCheckbox.IsChecked = false;
            TueCheckbox.IsChecked = false;
            WedCheckbox.IsChecked = false;
            ThuCheckbox.IsChecked = false;
            FriCheckbox.IsChecked = false;
            SatCheckbox.IsChecked = false;
            SunCheckbox.IsChecked = false;
            NoOfColumns1 = 0;
        }

        // Function to check which checkboxes (days) are checked and to calculate No. of Columns in the grid
        private void MonCheckbox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            string day = cb.Content.ToString();
            switch (day)
            {
                case "Mon":
                    int i = 1;
                    SelectedDays.Add(i);
                    break;
                case "Tue":
                    int j = 2;
                    SelectedDays.Add(j);
                    break;
                case "Wed":
                    int k = 3;
                    SelectedDays.Add(k);
                    break;
                case "Thu":
                    int l = 4;
                    SelectedDays.Add(l);
                    break;
                case "Fri":
                    int m = 5;
                    SelectedDays.Add(m);
                    break;
                case "Sat":
                    int n = 6;
                    SelectedDays.Add(n);
                    break;
                case "Sun":
                    int o = 7;
                    SelectedDays.Add(o);
                    break;
                default:
                    break;
            }
            NoOfColumns1 += 1;
        }

        // Function to check which checkboxes (days) will be unchecked after enabling and to calculate the exact No. of Columns in the grid
        private void MonCheckbox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            string day = cb.Content.ToString();
            switch (day)
            {
                case "Mon":
                    int i = 1;
                    SelectedDays.Remove(i);
                    break;
                case "Tue":
                    int j = 2;
                    SelectedDays.Remove(j);
                    break;
                case "Wed":
                    int k = 3;
                    SelectedDays.Remove(k);
                    break;
                case "Thu":
                    int l = 4;
                    SelectedDays.Remove(l);
                    break;
                case "Fri":
                    int m = 5;
                    SelectedDays.Remove(m);
                    break;
                case "Sat":
                    int n = 6;
                    SelectedDays.Remove(n);
                    break;
                case "Sun":
                    int o = 7;
                    SelectedDays.Remove(o);
                    break;
                default:
                    break;
            }
            NoOfColumns1 -= 1;
        }
    }
}
