﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTimeTableHelper
{
    public class GridInformation
    {
        public int TotalRows { get; set; }
        public int TotalColumns { get; set; }
        public ArrayList Days = new ArrayList();
        public int ClassStartTimeHour { get; set; }
        public int ClassStartTimeMinute { get; set; }
        public int EachClassHour { get; set; }
        public int EachClassMinute { get; set; }
    }
}
