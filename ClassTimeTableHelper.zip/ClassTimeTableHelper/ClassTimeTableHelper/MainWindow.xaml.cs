﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace ClassTimeTableHelper
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Variables to Generate TimeTable Grid
        public int NoOfColumns;
        public int NoOfRows;
        public ArrayList SelectedDays = new ArrayList();
        public int StartTimeHour;
        public int StartTimeMinute;
        public int EachHour;
        public int EachMinute;

        // Arrays and Variables to generate possibilities of the TimeTable
        public Button btn1;
        public Button btn2;
        public Course[,] CourseArray;
        public Course[] Course1dArray;
        public Course[,] Course2dArray;
        public int ArrayIndex = 0;
        public Random random = new Random();

        public ArrayList variable = new ArrayList();

        // Variables to add Course in the CourseListBox
        public string CourseName;
        public bool IsLab;
        public int CreditHour;

        public List<TextBlock> TextBlockList = new List<TextBlock>();   // To store Reference of Each TextBlock in the TimeTable Grid
        
        // To check data is sccessfully dropped in the TextBlock after dragging
        public bool isDropped = false;
        public bool isDropped1 = false;

        public List<Course> ListBoxArray = new List<Course>();  // To store Listbox Items in Xml File
        
        public string filename = null;  // To store save Xml file name
        public string filename1 = null; // To store open Xml file name
        public string filename2 = null; // To store save image file name
        
        public GridInformation gi;  // To store Tmetable Grid Rows and Columns in class and then in Xml file. 

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddGrid()
        {
            // Initializing GridInformation Class variables to store it in Xml File
            gi = new GridInformation();
            gi.TotalRows = this.NoOfRows;
            gi.TotalColumns = this.NoOfColumns;
            gi.ClassStartTimeHour = this.StartTimeHour;
            gi.ClassStartTimeMinute = this.StartTimeMinute;
            gi.EachClassHour = this.EachHour;
            gi.EachClassMinute = this.EachMinute;
            foreach (int item in SelectedDays)
            {
                gi.Days.Add(item);
            }

            // Intializing CourseArray to keep track of the Empty objects and the objects which conatins Course Information.
            CourseArray = new Course[(int)NoOfRows, NoOfColumns];
            
            // Clearing TimeTable Grid if user creates new TimeTable Grid
            TimeTableGrid.RowDefinitions.Clear();
            TimeTableGrid.ColumnDefinitions.Clear();
            TimeTableGrid.Children.Clear();
            CourseListbox.Items.Clear();
            MainGrid.Children.Remove(btn1);
            MainGrid.Children.Remove(btn2);
            TextBlockList.Clear();

            for (double i = 1; i <= NoOfRows + 1; i++)      // To add rows in the grid
            {
                RowDefinition row = new RowDefinition();
                TimeTableGrid.RowDefinitions.Add(row);
            }

            for (int i = 1; i <= NoOfColumns + 1; i++)      // To add columns in the grid
            {
                ColumnDefinition column = new ColumnDefinition();
                TimeTableGrid.ColumnDefinitions.Add(column);
            }

            for (int i = 0; i < NoOfRows + 1; i++)      // To print the border for each cell in the grid
            {
                for (int j = 0; j < NoOfColumns + 1; j++)
                {
                    Border bor = new Border();
                    if (i == 0 && j == 0)
                    {
                        bor.Background = System.Windows.Media.Brushes.Black;
                    }
                    else if (i == 0 && j != 0)
                    {
                        bor.Background = System.Windows.Media.Brushes.Black;
                    }
                    else if (j == 0 && i != 0)
                    {
                        bor.Background = System.Windows.Media.Brushes.Black;
                    }
                    else
                    {
                        bor.Background = Brushes.White;
                    }
                    // Apply Formatting
                    bor.BorderThickness = new Thickness(1, 1, 1, 1);
                    bor.BorderBrush = new SolidColorBrush(Colors.Black);
                    Grid.SetRow(bor, i);
                    Grid.SetColumn(bor, j);
                    TimeTableGrid.Children.Add(bor);
                }
            }

            // Inserting Empty Objects of Course Class in the CourseArray
            for (int i = 0; i < NoOfRows; i++)
            {
                for (int j = 0; j < NoOfColumns; j++)
                {
                    Course course = new Course();
                    CourseArray[i,j] = course;
                }
            }

            // Adding TextBlocks in the TimeTable Grid
            int k = 1;
            for (int i = 1; i < NoOfRows + 1; i++)
            {
                for (int j = 1; j < NoOfColumns + 1; j++)
                {
                    // Generating and TextBlock Objects
                    TextBlock tb = new TextBlock();

                    // Adding Context Menu to each TextBlocks generated at Runtime
                    ContextMenu cm = new ContextMenu();
                    tb.ContextMenu = cm;

                    MenuItem mi1 = new MenuItem();
                    mi1.Header = "Clash";
                    mi1.IsCheckable = true;
                    mi1.IsChecked = false;
                    mi1.AddHandler(MenuItem.CheckedEvent, new RoutedEventHandler(Clash_Checked));
                    mi1.AddHandler(MenuItem.UncheckedEvent, new RoutedEventHandler(Clash_Unchecked));
                    cm.Items.Add(mi1);

                    MenuItem mi2 = new MenuItem();
                    mi2.Header = "Lock";
                    mi2.IsCheckable = true;
                    mi2.IsChecked = false;
                    mi2.AddHandler(MenuItem.CheckedEvent, new RoutedEventHandler(Lock_Checked));
                    mi2.AddHandler(MenuItem.UncheckedEvent, new RoutedEventHandler(Lock_Unchecked));
                    cm.Items.Add(mi2);

                    MenuItem mi3 = new MenuItem();
                    mi3.Header = "Clear";
                    mi3.AddHandler(MenuItem.ClickEvent, new RoutedEventHandler(Clear_Click));
                    cm.Items.Add(mi3);
                    
                    // Applying TextBlock Formatting
                    tb.TextWrapping = TextWrapping.WrapWithOverflow;
                    tb.Width = 100;
                    tb.HorizontalAlignment = HorizontalAlignment.Center;
                    tb.VerticalAlignment = VerticalAlignment.Center;
                    tb.FontSize = 12;
                    tb.FontWeight = FontWeights.Bold;
                    tb.FontFamily = new System.Windows.Media.FontFamily("Segoe UI Black");
                    tb.AllowDrop = true;
                    tb.AddHandler(TextBlock.DropEvent, new DragEventHandler(textblock_Drop));
                    tb.AddHandler(TextBlock.MouseMoveEvent, new MouseEventHandler(textblock_MouseMove));
                    
                    // Setting TextBlocks position in the TimeTable Grid
                    k++;
                    Grid.SetRow(tb,i);
                    Grid.SetColumn(tb, j);
                    TimeTableGrid.Children.Add(tb);
                    TextBlockList.Add(tb);
                }
            }

            // Array to print Column Headers of the TimeTable Grid
            string[] days = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
            int col = 1;
            SelectedDays.Sort();
            foreach (int i in SelectedDays)         // To print the first row which contains the Days in which classes are conducted
            {
                TextBlock tb = new TextBlock();     // Creating TextBlock
                ContextMenu cm = new ContextMenu();
                tb.ContextMenu = cm;
                MenuItem mi = new MenuItem();
                mi.Header = "Lock Entire Column";
                mi.IsCheckable = true;
                mi.IsChecked = false;
                // Adding Event Handler to lock the Entire Column 
                mi.AddHandler(MenuItem.CheckedEvent, new RoutedEventHandler(Column_Checked));
                mi.AddHandler(MenuItem.UncheckedEvent, new RoutedEventHandler(Column_Unchecked));
                cm.Items.Add(mi);

                tb.Text = days[i - 1];              // Assigning text to the TextBlock from the 'days' array 

                // Formatting for the TextBlock
                tb.VerticalAlignment = VerticalAlignment.Center;
                tb.HorizontalAlignment = HorizontalAlignment.Center;
                tb.Foreground = System.Windows.Media.Brushes.White;
                tb.FontSize = 15;
                tb.FontWeight = FontWeights.Bold;
                tb.FontFamily = new System.Windows.Media.FontFamily("Microsoft New Tai Lue");

                // Adding TextBlock in the TimeTable Grid and Assigning position
                Grid.SetRow(tb, 0);
                Grid.SetColumn(tb, col);
                TimeTableGrid.Children.Add(tb);
                col++;
            }

            for (int i = 1; i <= NoOfRows; i++)      // To print the first column which contains time for each class
            {
                TextBlock tb = new TextBlock();
                ContextMenu cm = new ContextMenu();
                tb.ContextMenu = cm;
                MenuItem mi = new MenuItem();
                mi.Header = "Lock Entire Row";
                mi.IsCheckable = true;
                mi.IsChecked = false;
                // Adding Event Handlers to lock the entire row
                mi.AddHandler(MenuItem.CheckedEvent, new RoutedEventHandler(Row_Checked));
                mi.AddHandler(MenuItem.UncheckedEvent, new RoutedEventHandler(Row_Unchecked));
                cm.Items.Add(mi);

                // Calculating End Time of each class
                int EndTimeHour = StartTimeHour + EachHour;
                int EndTimeMinute = StartTimeMinute + EachMinute;

                if (EndTimeMinute >= 60)        // To check if minutes is not greater than 60
                {
                    EndTimeHour += 1;
                    EndTimeMinute = EndTimeMinute % 60;
                }
                if (StartTimeMinute == 0 && EndTimeMinute == 0)
                {
                    tb.Text = StartTimeHour.ToString() + ":00" + " - " + EndTimeHour.ToString() +       // Assigning Text
                    ":00";
                }
                else if (EndTimeMinute == 0)     // if else condition to print double zero if Minutes are zero
                {
                    tb.Text = StartTimeHour.ToString() + ":" + StartTimeMinute.ToString() + " - " + EndTimeHour.ToString() +       // Assigning Text
                    ":00";
                }
                else if (StartTimeMinute == 0)
                {
                    tb.Text = StartTimeHour.ToString() + ":00" + " - " + EndTimeHour.ToString() +       // Assigning Text
                    ":" + EndTimeMinute.ToString();
                }
                else
                {
                    tb.Text = StartTimeHour.ToString() + ":" + StartTimeMinute.ToString() + " - " + EndTimeHour.ToString() +
                    ":" + EndTimeMinute.ToString();
                }
                // Formatting of the TextBlock
                tb.VerticalAlignment = VerticalAlignment.Center;
                tb.HorizontalAlignment = HorizontalAlignment.Center;
                tb.FontSize = 15;
                tb.Foreground = System.Windows.Media.Brushes.White;
                tb.FontWeight = FontWeights.Bold;
                tb.FontFamily = new System.Windows.Media.FontFamily("Microsoft New Tai Lue");

                // Adding TextBlock in the Grid and Assigning position
                Grid.SetRow(tb, i);
                Grid.SetColumn(tb, 0);
                TimeTableGrid.Children.Add(tb);
                // Assigning End Time to Start Time for the new class
                StartTimeHour = EndTimeHour;
                StartTimeMinute = EndTimeMinute;
            }
            // All variables will be reset to default values for creating the new Timetable grid for the next time
            NoOfRows = 0;
            SelectedDays.Clear();
            NoOfColumns = 0;
            StartTimeHour = 0;
            StartTimeMinute = 0;
            EachHour = 0;
            EachMinute = 0;
        }

        // Function to Handle Clash TextBlock Event
        private void Clash_Checked(object sender, RoutedEventArgs e)
        {
            TextBlock tb = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBlock;
            tb.Foreground = System.Windows.Media.Brushes.Red;
            tb.Opacity = 0.5;
            tb.IsEnabled = false;
            ContextMenuService.SetShowOnDisabled(tb, true);

            int row = Grid.GetRow(tb);
            int column = Grid.GetColumn(tb);
            CourseArray[row - 1, column - 1].IsLocked = true;
        }

        // Function to Handle Clash TextBlock Event
        private void Clash_Unchecked(object sender, RoutedEventArgs e)
        {
            TextBlock tb = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBlock;
            tb.Foreground = System.Windows.Media.Brushes.Black;
            tb.Opacity = 1;
            tb.IsEnabled = true;

            int row = Grid.GetRow(tb);
            int column = Grid.GetColumn(tb);
            CourseArray[row - 1, column - 1].IsLocked = false;
        }

        // Function to Handle Lock TextBlock Event
        private void Lock_Checked(object sender, RoutedEventArgs e)
        {
            TextBlock tb = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBlock;
            tb.Opacity = 0.5;
            tb.IsEnabled = false;
            ContextMenuService.SetShowOnDisabled(tb, true);

            int row = Grid.GetRow(tb);
            int column = Grid.GetColumn(tb);
            CourseArray[row - 1, column - 1].IsLocked = true;
        }

        // Function to Handle Lock TextBlock Event
        private void Lock_Unchecked(object sender, RoutedEventArgs e)
        {
            TextBlock tb = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBlock;
            tb.Opacity = 1;
            tb.IsEnabled = true;

            int row = Grid.GetRow(tb);
            int column = Grid.GetColumn(tb);
            CourseArray[row - 1, column - 1].IsLocked = false;
        }

        // Function to Handle Clear TextBlock Event
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            TextBlock tb = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBlock;
            tb.Text = "";
        }

        // Function to Handle Lock Entire Column Event
        private void Column_Checked(object sender, RoutedEventArgs e)
        {
            TextBlock tb = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBlock;
            int i = TimeTableGrid.RowDefinitions.Count;
            int column = Grid.GetColumn(tb);
            for (int row = 1; row < i; row++)
            {
                CourseArray[row - 1, column - 1].IsLocked = true;

                foreach (UIElement item in TimeTableGrid.Children)
                {                    
                    if (Grid.GetRow(item) == row && Grid.GetColumn(item) == column)
                    {
                        item.Opacity = 0.5;
                        item.IsEnabled = false;
                        ContextMenuService.SetShowOnDisabled(item, true);
                    }
                }
            }
        }

        // Function to Handle Lock Entire Column Event
        private void Column_Unchecked(object sender, RoutedEventArgs e)
        {
            TextBlock tb = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBlock;
            int i = TimeTableGrid.RowDefinitions.Count;
            int column = Grid.GetColumn(tb);
            for (int row = 1; row < i; row++)
            {
                foreach (UIElement item in TimeTableGrid.Children)
                {
                    CourseArray[row - 1, column - 1].IsLocked = false;

                    if (Grid.GetRow(item) == row && Grid.GetColumn(item) == column)
                    {
                        item.Opacity = 1;
                        item.IsEnabled = true;
                    }
                }
            }
        }

        // Function to Handle Lock Entire Row Event
        private void Row_Checked(object sender, RoutedEventArgs e)
        {
            TextBlock tb = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBlock;
            int i = TimeTableGrid.ColumnDefinitions.Count;
            int row = Grid.GetRow(tb);
            for (int column = 1; column < i; column++)
            {
                CourseArray[row - 1, column - 1].IsLocked = true;

                foreach (UIElement item in TimeTableGrid.Children)
                {
                    if (Grid.GetRow(item) == row && Grid.GetColumn(item) == column)
                    {
                        item.Opacity = 0.5;
                        item.IsEnabled = false;
                        ContextMenuService.SetShowOnDisabled(item, true);
                    }
                }
            }
        }

        // Function to Handle Lock Entire Row Event
        private void Row_Unchecked(object sender, RoutedEventArgs e)
        {
            TextBlock tb = ((sender as MenuItem).Parent as ContextMenu).PlacementTarget as TextBlock;
            int i = TimeTableGrid.ColumnDefinitions.Count;
            int row = Grid.GetRow(tb);
            for (int column = 1; column < i; column++)
            {
                CourseArray[row - 1, column - 1].IsLocked = false;

                foreach (UIElement item in TimeTableGrid.Children)
                {
                    if (Grid.GetRow(item) == row && Grid.GetColumn(item) == column)
                    {
                        
                        item.Opacity = 1;
                        item.IsEnabled = true;
                    }
                }
            }
        }

        // Function to gather Timetable Grid Information in order to generate it
        private void AddGridItem_Click(object sender, RoutedEventArgs e)
        {
            AddGridWindow window = new AddGridWindow();
            window.ShowDialog();
            if (window.AddGridButtonClicked)
            {
                AddGrid();
                window.AddGridButtonClicked = false;
            }
        }

        // Function to gather CourseListBox Information in order to generate it
        private void AddCourseItem_Click(object sender, RoutedEventArgs e)
        {
            AddCourseWindow window = new AddCourseWindow();
            window.ShowDialog();
            if (window.AddCourseButtonClicked)
            {
                AddCourse();
                window.AddCourseButtonClicked = false;
            }
        }

        // Function to print CourseListBox items in the ListBox
        private void AddCourse()
        {
            if (IsLab == true)
            {
                for (int i = 1; i <= 2; i++)
                {
                    Course course1 = new Course(this.CourseName + "[Theory]", this.IsLab, this.CreditHour, false);
                    this.CourseListbox.Items.Add(course1);
                    ListBoxArray.Add(course1);
                }
                for (int i = 1; i <= 2; i++)
                {
                    Course course2 = new Course(this.CourseName + "[Lab(1.5 Hours)]", this.IsLab, this.CreditHour, false);
                    this.CourseListbox.Items.Add(course2);
                    ListBoxArray.Add(course2);
                }
            }
            else
            {
                for (int i = 1; i <= 2; i++)
                {
                    Course course1 = new Course(this.CourseName + "[Theory]", this.IsLab, this.CreditHour, false);
                    this.CourseListbox.Items.Add(course1);
                    ListBoxArray.Add(course1);
                }
            }
        }

        // Drag function for the CourseListBox
        private void CourseListbox_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    Course item = (Course)CourseListbox.SelectedItem;
                    DragDrop.DoDragDrop(this, new DataObject(DataFormats.StringFormat, item), DragDropEffects.Move);
                    if (isDropped)
                    {
                        CourseListbox.Items.Remove(item);
                        ListBoxArray.Remove(item);
                        isDropped = false;
                    }
                }
            }
            catch { }
            
        }

        // Drop function for the TextBlock
        private void textblock_Drop(object sender, DragEventArgs e)
        {
            TextBlock tb = sender as TextBlock;
            int row = Grid.GetRow(tb);
            int column = Grid.GetColumn(tb);
            //MessageBox.Show("Row = "+row+" , Column = "+column);
            if (e.Data.GetData(DataFormats.StringFormat) is Course ListItem)
            {
                isDropped = true;
                tb.Text = ListItem.CourseName.ToString();
                CourseArray[row-1, column-1] = ListItem;
            }
            else if (e.Data.GetData(DataFormats.StringFormat) is TextBlock tb1)
            {
                isDropped1 = true;
                tb.Text = tb1.Text;
                Course cou = new Course();
                cou.CourseName = tb1.Text;
                CourseArray[row-1, column-1] = cou;
            }
            
        }

        // Drag function for the TextBlock
        private void textblock_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    TextBlock tb = sender as TextBlock;
                    int row = Grid.GetRow(tb);
                    int column = Grid.GetColumn(tb);
                    DragDrop.DoDragDrop(this, new DataObject(DataFormats.StringFormat, tb), DragDropEffects.Move);
                    if (isDropped1)
                    {
                        Course cou = new Course();
                        CourseArray[row-1, column-1] = cou;
                        tb.Text = "";
                        isDropped1 = false;
                    }
                }
            }
            catch { }
        }

        // Drop function for the CourseListBox
        private void CourseListbox_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetData(DataFormats.StringFormat) is TextBlock tb)
            {
                Course cou = new Course();
                cou.CourseName = tb.Text;
                CourseListbox.Items.Add(cou);
                ListBoxArray.Add(cou);
                isDropped1 = true;
            }
        }
         // Function to Apply Formatting to the Runtime Generated Button
        private void ApplyFormatting(Button btn, int row, int column)
        {
            btn.Width = 50;
            btn.Height = 100;
            btn.FontSize = 50;
            btn.Foreground = System.Windows.Media.Brushes.White;
            btn.Background = System.Windows.Media.Brushes.Black;
            btn.FontWeight = FontWeights.Bold;
            btn.FontFamily = new System.Windows.Media.FontFamily("Microsoft New Tai Lue");
            btn.VerticalAlignment = VerticalAlignment.Center;
            btn.HorizontalAlignment = HorizontalAlignment.Center;
            Grid.SetRow(btn, row);
            Grid.SetColumn(btn, column);
            MainGrid.Children.Add(btn);

        }
        
        // Function which Initializes the Course Arrays and Generate Possibilities for the TimeTable Grid
        private void GeneratePossibility_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MainGrid.Children.Remove(btn1);
                MainGrid.Children.Remove(btn2);

                ArrayIndex = 0;
                if (Course1dArray != null)
                {
                    Course1dArray = null;
                }
                int size = CourseArray.GetLength(0) * CourseArray.GetLength(1);     // Calulating size for the Course1dArray

                // Initializing Course1dArray and Course2dArray to Store data in it
                Course1dArray = new Course[size];       // This Array is used to convert 2d Array (means CourseArray) into 1d array to generate possibilities easily 
                Course2dArray = new Course[25, size];   // this Array is used to store all generated possiblities
                
                // Converting 2d 'CourseArray' into 1d 'Course1dArray' 
                int k = 0;
                for (int i = 0; i < CourseArray.GetLength(0); i++)
                {
                    for (int j = 0; j < CourseArray.GetLength(1); j++)
                    {
                        Course1dArray[k] = CourseArray[i, j];
                        k++;
                    }
                }
                // Saving first possibility in Course2dArray which is same as user Created in the TimeTable Grid
                for (int i = 0; i < size; i++)
                {
                    Course2dArray[0, i] = Course1dArray[i];
                }

                // Saving Remaining Possibilities
                for (int i = 1; i < Course2dArray.GetLength(0); i++)
                {
                    GeneratePossibilities(Course1dArray);
                    for (int j = 0; j < Course2dArray.GetLength(1); j++)
                    {
                        Course2dArray[i, j] = Course1dArray[j];
                    }
                }

                // Creating Previous Button to print the previous possibility
                btn1 = new Button();
                btn1.Content = "<";
                btn1.AddHandler(Button.ClickEvent, new RoutedEventHandler(btn1_Click));
                ApplyFormatting(btn1, 2, 1);

                // Creating Next Button to print the next possibility
                btn2 = new Button();
                btn2.Content = ">";
                btn2.AddHandler(Button.ClickEvent, new RoutedEventHandler(btn2_Click));
                ApplyFormatting(btn2, 2, 3);
            }
            catch (System.NullReferenceException ex)
            {
                MessageBox.Show("Please First Create Grid and insert Courses, then you will be able to generate possibilities.");
            }
            
        }
        
        // Function to Generate Possibilities
        public void GeneratePossibilities(Course[] arr)
        {
            int index; 
            Course temp;
            for (int i = arr.Length - 1; i > 0; i--)
            {
                index = random.Next(0, arr.Length);
                if(arr[index].IsLocked == true || arr[i].IsLocked == true)
                {
                    continue;
                }
                temp = arr[index];
                arr[index] = arr[i];
                arr[i] = temp;
            }
        }
        // Function to move backward in the Course2dArray
        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ArrayIndex == 0) // if function reaches the zeroth index of the Course2dArray then array index will be again at last index of array
                {
                    ArrayIndex = Course2dArray.GetLength(0);
                }
                ArrayIndex--;

                // Printing Possibility in the TimeTable Grid using Textblocks
                int k = 0;
                foreach (TextBlock tb in TextBlockList)
                {
                    tb.Text = Course2dArray[ArrayIndex, k].CourseName;
                    k++;
                }

            // Also Again Initializing CourseArray to generate new possibility
            k = 0;
            for (int i = 0; i < CourseArray.GetLength(0); i++)
            {
                for (int j = 0; j < CourseArray.GetLength(1); j++)
                {
                    CourseArray[i, j] = Course2dArray[ArrayIndex, k];
                    k++;
                }
            }

            // Also Again Initializing Course1dArray to store it in Xml File
            k = 0;
                for (int i = 0; i < CourseArray.GetLength(0); i++)
                {
                    for (int j = 0; j < CourseArray.GetLength(1); j++)
                    {
                        Course1dArray[k] = Course2dArray[ArrayIndex, k];
                        k++;
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please First Generate Possibities of the Grid.");
            }
            
        }

        // Function to move forward in the Course2dArray
        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ArrayIndex == Course2dArray.GetLength(0) - 1) // if function reaches the last index of the Course2dArray then array index will be again at zeroth index of array
                {
                    ArrayIndex = -1;
                }
                ArrayIndex++;

                // Printing Possibility in the TimeTable Grid using Textblocks
                int k = 0;
                foreach (TextBlock tb in TextBlockList)
                {
                    tb.Text = Course2dArray[ArrayIndex, k].CourseName;
                    k++;
                }

                // Also Again Initializing Course1dArray to store it in Xml File
                k = 0;
                for (int i = 0; i < CourseArray.GetLength(0); i++)
                {
                    for (int j = 0; j < CourseArray.GetLength(1); j++)
                    {
                        CourseArray[i, j] = Course2dArray[ArrayIndex, k];
                        k++;
                    }
                }

                // Also Again Initializing Course1dArray to store it in Xml File
                k = 0;
                for (int i = 0; i < CourseArray.GetLength(0); i++)
                {
                    for (int j = 0; j < CourseArray.GetLength(1); j++)
                    {
                        Course1dArray[k] = Course2dArray[ArrayIndex, k];
                        k++;
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please First Generate Possibities of the Grid.");
            }
}

        // Function to Save Xml File
        private void SaveItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Course1dArray == null)
                {
                    Course1dArray = new Course[CourseArray.GetLength(0) * CourseArray.GetLength(1)];
                    int a = 0;
                    for (int i = 0; i < CourseArray.GetLength(0); i++)
                    {
                        for (int j = 0; j < CourseArray.GetLength(1); j++)
                        {
                            Course1dArray[a] = CourseArray[i, j];
                            a++;
                        }
                    }
                }
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.FileName = "Document";
                sfd.Filter = "Xml Files(*.Xml)|*.Xml";
                if (sfd.ShowDialog() == true)
                {
                    filename = sfd.FileName;
                }

                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.IndentChars = "\t";

                XmlWriter w = XmlWriter.Create(filename,settings);

                w.WriteStartDocument();
                w.WriteStartElement("TimeTableGrid");

                w.WriteStartElement("GridInformation");
                w.WriteStartElement("Days");
                foreach (int item in gi.Days)
                {
                    w.WriteElementString("AnyType", item.ToString());
                }
                w.WriteEndElement();
                w.WriteElementString("TotalRows", gi.TotalRows.ToString());
                w.WriteElementString("TotalColumns", gi.TotalColumns.ToString());
                w.WriteElementString("ClassStartTimeHour", gi.ClassStartTimeHour.ToString());
                w.WriteElementString("ClassStartTimeMinute", gi.ClassStartTimeMinute.ToString());
                w.WriteElementString("EachClassHour", gi.EachClassHour.ToString());
                w.WriteElementString("EachClassMinute", gi.EachClassMinute.ToString());
                w.WriteEndElement();

                w.WriteStartElement("GridCourseInformation");

                foreach (Course item in Course1dArray)
                {
                    w.WriteStartElement("Course");
                    w.WriteElementString("CourseName",item.CourseName);
                    w.WriteElementString("IsLab", (item.IsLab).ToString());
                    w.WriteElementString("CreditHour", (item.CreditHour).ToString());
                    w.WriteEndElement();
                }

                w.WriteEndElement();

                w.WriteStartElement("ListBoxCourseInformation");

                foreach (Course item in ListBoxArray)
                {
                    w.WriteStartElement("Course");
                    w.WriteElementString("CourseName", item.CourseName);
                    w.WriteElementString("IsLab", (item.IsLab).ToString());
                    w.WriteElementString("CreditHour", (item.CreditHour).ToString());
                    w.WriteEndElement();
                }

                w.WriteEndElement();
                w.WriteEndDocument();
                w.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please first add Courses and Create Timetable to save data.");
            }
        }

        private void OpenItem_Click(object sender, RoutedEventArgs e)
        {
            try {
                clear(sender, e);

                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "Xml Files(*.Xml)|*.Xml";
                if (ofd.ShowDialog() == true)
                {
                    filename1 = ofd.FileName;
                }

                XmlReader r = XmlReader.Create(filename1);

                r.ReadToFollowing("Days");
                XmlReader days = r.ReadSubtree();
                while (days.ReadToFollowing("AnyType"))
                {
                    SelectedDays.Add(Int32.Parse(days.ReadElementContentAsString()));
                }
                days.Close();
                r.ReadToFollowing("TotalRows");
                NoOfRows = Int32.Parse(r.ReadString());
                r.ReadToFollowing("TotalColumns");
                NoOfColumns = Int32.Parse(r.ReadString());
                r.ReadToFollowing("ClassStartTimeHour");
                StartTimeHour = Int32.Parse(r.ReadString());
                r.ReadToFollowing("ClassStartTimeMinute");
                StartTimeMinute = Int32.Parse(r.ReadString());
                r.ReadToFollowing("EachClassHour");
                EachHour = Int32.Parse(r.ReadString());
                r.ReadToFollowing("EachClassMinute");
                EachMinute = Int32.Parse(r.ReadString());
                AddGrid();


                Course1dArray = new Course[CourseArray.GetLength(0) * CourseArray.GetLength(1)];
                int k = 0;
                for (int i = 0; i < CourseArray.GetLength(0); i++)
                {
                    for (int j = 0; j < CourseArray.GetLength(1); j++)
                    {
                        Course1dArray[k] = CourseArray[i, j];
                        k++;
                    }
                }
                k = 0;
                r.ReadToFollowing("GridCourseInformation");
                XmlReader courses = r.ReadSubtree();
                while (courses.ReadToFollowing("Course"))
                {
                    courses.ReadToFollowing("CourseName");
                    Course1dArray[k].CourseName = courses.ReadElementContentAsString();
                    courses.ReadToFollowing("IsLab");
                    Course1dArray[k].IsLab = Boolean.Parse(courses.ReadElementContentAsString());
                    courses.ReadToFollowing("CreditHour");
                    Course1dArray[k].CreditHour = Int32.Parse(courses.ReadElementContentAsString());
                    k++;
                }
                k = 0;
                foreach (TextBlock tb in TextBlockList)
                {
                    tb.Text = Course1dArray[k].CourseName;
                    k++;
                }

                r.ReadToFollowing("ListBoxCourseInformation");
                XmlReader listbox = r.ReadSubtree();
                while (listbox.ReadToFollowing("Course"))
                {
                    Course cou = new Course();
                    listbox.ReadToFollowing("CourseName");
                    cou.CourseName = listbox.ReadElementContentAsString();
                    listbox.ReadToFollowing("IsLab");
                    cou.IsLab = Boolean.Parse(listbox.ReadElementContentAsString());
                    listbox.ReadToFollowing("CreditHour");
                    cou.CreditHour = Int32.Parse(listbox.ReadElementContentAsString());
                    ListBoxArray.Add(cou);
                    CourseListbox.Items.Add(cou);
                }
                r.Close();
            }
            catch { }
        }

        private void ClearItem_Click(object sender, RoutedEventArgs e)
        {
            MainGrid.Children.Remove(btn1);
            MainGrid.Children.Remove(btn2);
            NoOfRows = 0;
            SelectedDays.Clear();
            NoOfColumns = 0;
            StartTimeHour = 0;
            StartTimeMinute = 0;
            EachHour = 0;
            EachMinute = 0;
            TimeTableGrid.RowDefinitions.Clear();
            TimeTableGrid.ColumnDefinitions.Clear();
            TimeTableGrid.Children.Clear();
            CourseListbox.Items.Clear();
            ListBoxArray.Clear();
        }

        private void clear(object sender, RoutedEventArgs e)
        {
            ClearItem_Click(sender, e);
            TextBlockList.Clear();
            filename1 = "";
            CourseArray = null;
            Course1dArray = null;
            Course2dArray = null;
        }

        private void SaveImageItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.FileName = "Document";
                sfd.Filter = "PNG Files(*.png)|*.png";
                if (sfd.ShowDialog() == true)
                {
                    filename2 = sfd.FileName;
                }

                RenderTargetBitmap rtb = new RenderTargetBitmap((int)TimeTableGrid.ActualWidth, (int)TimeTableGrid.ActualHeight, 96, 96, PixelFormats.Pbgra32);
                rtb.Render(TimeTableGrid);
                PngBitmapEncoder pbe = new PngBitmapEncoder();
                pbe.Frames.Add(BitmapFrame.Create(rtb));
                FileStream fs = new FileStream(filename2, FileMode.Create);
                pbe.Save(fs);
                fs.Close();
            }
            catch { }
        }
    }
}
