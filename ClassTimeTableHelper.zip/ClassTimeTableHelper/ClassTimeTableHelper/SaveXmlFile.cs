﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;
using System.Xml;
using System.Windows;

namespace ClassTimeTableHelper
{
    public class SaveXmlFile
    {

        public static Object RetrieveXmlData(Object obj, string filename)
        {
            XmlReader xmlreader = XmlReader.Create(filename);
            string WantedNode = "";
            while (xmlreader.Read())
            {
                if (xmlreader.NodeType == XmlNodeType.Element && xmlreader.Name == "GridInformation")
                {
                    WantedNode = xmlreader.ReadOuterXml();
                    break;
                }
            }
            MessageBox.Show(WantedNode);
            XmlSerializer sr = new XmlSerializer(obj.GetType());
            //FileStream fs = new FileStream(WantedNode, FileMode.Open, FileAccess.Read, FileShare.None);
            //TextReader reader = new StreamReader(WantedNode);
            return sr.Deserialize(xmlreader,WantedNode);
        }
    }
}
