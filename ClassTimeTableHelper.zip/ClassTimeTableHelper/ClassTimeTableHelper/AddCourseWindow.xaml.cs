﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ClassTimeTableHelper
{
    /// <summary>
    /// Interaction logic for AddCourseWindow.xaml
    /// </summary>
    public partial class AddCourseWindow : Window
    {
        public bool AddCourseButtonClicked = false;
        public AddCourseWindow()
        {
            InitializeComponent();
        }

        private void LabYesRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            this.FourHourRadioButton.IsEnabled = true;
        }

        private void LabYesRadioButton_Unchecked(object sender, RoutedEventArgs e)
        {
            this.FourHourRadioButton.IsEnabled = false;
            this.ThreeHourRadioButton.IsChecked = true;
        }

        private void AddCourseButton_Click(object sender, RoutedEventArgs e)
        {
            if (CourseNameTextbox.Text != "")
            {
                foreach (Window window in Application.Current.Windows)
                {
                    if (window.GetType() == typeof(MainWindow))
                    {
                        (window as MainWindow).CourseName = CourseNameTextbox.Text;
                        if ((bool)LabYesRadioButton.IsChecked)
                        {
                            (window as MainWindow).IsLab = true;
                        }
                        else
                        {
                            (window as MainWindow).IsLab = false;
                        }
                        if ((bool)ThreeHourRadioButton.IsChecked)
                        {
                            (window as MainWindow).CreditHour = 3;
                        }
                        else
                        {
                            (window as MainWindow).CreditHour = 4;
                        }
                    }
                }
                AddCourseButtonClicked = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("Course Name cannot be empty.");
            }
            
        }
    }
}
